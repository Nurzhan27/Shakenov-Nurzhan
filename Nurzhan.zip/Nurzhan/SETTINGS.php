<?php
	$ADMIN = 'nurzhan';
	$SITE_DOMAIN = 'nurzhan/';
	$AUTHOR = 'NURZHAN';
	$DB_SERVER = 'localhost';
	$DB_ACC = [
    	'login' => 'root',
    	'password' => '',
	];
	$DB_NAME = 'proforientationdb';
	$MIGRATIONS = 'none';
	$ADMIN = "Nurzhan";
?>